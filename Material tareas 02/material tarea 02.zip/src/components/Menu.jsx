import React from 'react'

function Menu() {
    return (
        <div className="menu">
            <h2>Tareas</h2>
        </div>
    )
}

export default Menu