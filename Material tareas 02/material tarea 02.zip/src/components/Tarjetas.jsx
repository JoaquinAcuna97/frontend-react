import React from 'react'
import Tarjeta from './Tarjeta'

function Tarjetas() {
    return (
        <div className="tarjetas">
            <Tarjeta></Tarjeta>
            <Tarjeta></Tarjeta>
        </div>
    )
}

export default Tarjetas