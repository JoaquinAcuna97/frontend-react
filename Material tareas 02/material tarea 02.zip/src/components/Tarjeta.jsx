import React from 'react'

function Tarjeta() {
    return (
        <div className="tarjeta">
            <input type="checkbox" id="list02" className="checkbox" />
            <label className="checkLabel" htmlFor="list02">Segunda tarea a realizar</label>
        </div>
    )
}

export default Tarjeta